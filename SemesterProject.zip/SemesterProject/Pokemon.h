#pragma once
#include <string>
#include <cstdlib>
#include <map>
#include <unordered_map>
#include <ctime>
using namespace std;



class Pokemon
{
public:
	Pokemon();
	~Pokemon();
	bool operator>(const Pokemon& pkmn2);
	struct Move {
		string atkName;
		double pwr;
		double acc;
		string atkType;
		Move() { atkName = "atk"; pwr = 0.0; acc = 100.0; atkType = "normal"; }
		Move(string atkName, double pwr, double acc, string atkType);
	};
	
	//virtual void passiveEffect() = 0;
	virtual double MakeAttack(const Move& attack, const string& opp_type);
	virtual void TakeDamage(const double);
	string getType() const {
		return pkmnType;
	}
	string getName() const {
		return pkmnName;
	}
	
	
	int hp;
	Move movelist[4];
protected:
	string pkmnType;
	string pkmnName;
	static unordered_map<string, map<string, double> > make_map();
	static unordered_map<string, map<string, double> > TypeList;
	int atk;
	int def;
	int spd;

	
	
};

